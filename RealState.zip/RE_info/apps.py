from django.apps import AppConfig


class ReInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RE_info'
