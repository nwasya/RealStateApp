from django.apps import AppConfig


class ReNewsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RE_news'
