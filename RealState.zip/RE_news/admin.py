from django.contrib import admin

# Register your models here.
from RE_news.models import News

admin.site.register(News)