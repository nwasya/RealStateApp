from django.apps import AppConfig


class ReUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RE_user'
