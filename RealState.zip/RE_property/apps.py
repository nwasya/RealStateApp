from django.apps import AppConfig


class RePropertyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RE_property'
